<div class="position-relative form-group">
    <label for="img" class="">Foto</label>
    <?php if(empty(!$admin->img)): ?>
    <img src="<?php echo e($admin->takeImg); ?>" alt="Error" width="100" for="img">
    <?php endif; ?>
    <input name="img" id="img" placeholder="input your img" type="file" accept="image/*" class="form-control" autofocus>
    <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small> 
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="position-relative form-group">
    <label for="nama" class="">Nama</label>
    <input name="name" id="nama" placeholder="nama pengguna" autocomplete="off" type="text" class="form-control" value="<?php echo e(old('name') ?? $admin->name); ?>">
    <?php if($errors->has('name')): ?>
        <small class="text-danger"><?php echo e($errors->first('name')); ?></small>
    <?php endif; ?>
</div>
<div class="position-relative form-group">
    <label for="email" class="">Email</label>
    <input name="email" id="email" placeholder="email pengguna" autocomplete="off" type="email" class="form-control" value="<?php echo e(old('email') ?? $admin->email); ?>">
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small> 
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="position-relative form-group">
    <label for="password" class="">Password</label>
    <input name="password" id="password" placeholder="password pengguna" autocomplete="off" type="password" class="form-control">
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small> 
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="position-relative form-group">
    <label for="password_confirmation" class="">Konfirmasi Password</label>
    <input name="password_confirmation" id="password_confirmation" placeholder="password konfirmasi" autocomplete="off" type="password" class="form-control">
</div><?php /**PATH C:\Users\A C E R\Desktop\web_api_game\resources\views/components/backend/admin_form.blade.php ENDPATH**/ ?>