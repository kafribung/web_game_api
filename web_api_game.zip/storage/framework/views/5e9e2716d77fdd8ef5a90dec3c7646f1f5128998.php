<link href="<?php echo e(asset('main.css')); ?>" rel="stylesheet">
<?php /**PATH C:\Users\A C E R\Desktop\web_api_wisata\resources\views/includes/css_dash.blade.php ENDPATH**/ ?>