
<?php $__env->startSection('content'); ?>
<div class="app-main__inner">
    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="pe-7s-car icon-gradient bg-mean-fruit">
                    </i>
                </div>
                <div>Game
                    <div class="page-title-subheading">Menampilkan semua data game.</div>
                </div>
            </div>
        </div>
    </div>
    <?php if(session('msg')): ?>
    <div class="row">
        <p class="alert alert-success"><?php echo e(session('msg')); ?></p>
    </div>
    <?php endif; ?>

    <div class="row">
        <a href="<?php echo e(route('game.create')); ?>" class="btn btn-outline-primary mb-1"><i class="fa fa-plus"></i></a>
    </div>

    <div class="row" id="app">
        <?php $__empty_1 = true; $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-6 col-xl-4">
            <div class="mb-3 card card-body">
                <h5 class="card-title"><?php echo e($game->name); ?> <sup class="badge badge-info"><?php echo e($game->duration); ?> menit</sup></h5>
                <p><?php echo e($game->user->name); ?></p>
                <img src="<?php echo e($game->takeImg); ?>" class="card-img-top" alt="Error" width="200" height="200"> 
                <p><?php echo Str::limit($game->description, 200); ?></p>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isOwner', $game)): ?>
                <a href="<?php echo e(route('game.edit', $game->slug)); ?>" class="btn btn-outline-warning mb-1"><i class="fa fa-edit"></i></a>
                <button ref="deleteGame" v-on:click='deleteGame(<?php echo e($game->id); ?>)' class="btn btn-outline-danger"><i class="fa fa-trash"></i></button>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h5 class="text-info">Data game belum ditambahkan</h5>
        <?php endif; ?>
    </div>
</div>
<?php $__env->startPush('script_vue_js_axios_sweet'); ?>
    <script src="https://cdn.jsdelivr.net/npm/vue@2.6.12/dist/vue.js"></script>   
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script> 
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script>
        var app = new Vue({
            el: '#app',
            methods: {
                deleteGame(id) {
                    swal({
                        title: "Apakah kamu yakin?",
                            text: "Setelah dihapus, Anda tidak akan dapat memulihkan file  ini!",
                            icon: "warning",
                            buttons: true,
                            dangerMode: true,
                            })
                            .then((willDelete) => {
                            if (willDelete) {
                                swal("File berhasil dihapus!", {
                                    icon: "success",
                                });
                                axios
                                    .delete('/game/' + id)
                                    .then((response) => {
                                    this.$refs.deleteGame.parentNode.parentNode.remove();
                                    location.reload();
                                    });
                            } else {
                                swal("File gagal dihapus!");
                            }
                        });
                }
            },
        })
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_dash', ['title' => 'Dashboard - Game'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\A C E R\Desktop\web_api_game\resources\views/backend/game.blade.php ENDPATH**/ ?>