<div class="app-wrapper-footer">
    <div class="app-footer">
        <div class="app-footer__inner">
            <div class="app-footer-right">
                <ul class="nav">
                    <li class="nav-item">
                        <a href="javascript:void(0);" class="nav-link">
                            <div class="badge badge-success mr-1 ml-0">
                                <small>Nomads Dev</small>
                            </div>
                            UIN Alauddin Makassar
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\A C E R\Desktop\web_api_game\resources\views/layouts/master_footer.blade.php ENDPATH**/ ?>