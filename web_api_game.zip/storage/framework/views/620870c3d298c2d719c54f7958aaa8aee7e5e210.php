
<?php $__env->startSection('content'); ?>
<div class="app-main__inner" id="app">
    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="pe-7s-display1 icon-gradient bg-premium-dark">
                    </i>
                </div>
                <div>admin
                    <div class="page-title-subheading"> All admin data.</div>
                </div>
            </div>
        </div>
    </div>
    <?php if(session('msg')): ?>
    <div class="row">
        <p class="alert alert-success"><?php echo e(session('msg')); ?></p>
    </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <h5 class="card-title">Table with hover</h5>
                    <?php if(Auth::user()->king()): ?>
                    <a href="/admin/create" class="btn btn-primary btn-sm float-right"><i class="fa fa-plus"></i></a>
                    <?php endif; ?>
                    <table class="mb-0 table table-hover">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Foto</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                            $angkaAwal = 1
                        ?>
                        <?php $__empty_1 = true; $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th scope="row"><?php echo e($angkaAwal++); ?></th>
                            <td><img src="<?php echo e($admin->takeImg); ?>" alt="Error" width="100"></td>
                            <td><?php echo e($admin->name); ?></td>
                            <td><?php echo e($admin->email); ?></td>
                            <td>
                                <?php if($admin->king()): ?>
                                <a href="/admin/<?php echo e($admin->email); ?>/edit" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a>
                                <button ref="deleteAdmin" v-on:click="deleteAdmin(<?php echo e($admin->id); ?>)" class="btn btn-danger btn-sm d-inline-block"><i class="fa fa-trash"></i></button>
                                <?php endif; ?>
                            </td>
                        </tr>    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <h2>The admin is null</h2>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('script_vue_js_axios_sweet'); ?>
    <script src="https://cdn.jsdelivr.net/npm/vue@2.6.12/dist/vue.js"></script>   
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script> 
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script>
        var app = new Vue({
            el: '#app',
            methods: {
                deleteAdmin(id) {

                    swal({
                            title: "Are you sure?",
                            text: "Once deleted, you will not be able to recover this imaginary file!",
                            icon: "warning",
                            buttons: true,
                            dangerMode: true,
                            })
                            .then((willDelete) => {
                            if (willDelete) {
                                swal("Poof! Your imaginary file has been deleted!", {
                                    icon: "success",
                                });
                                axios
                                    // .delete(`/admin/${id}`)
                                    .delete('/admin/' + id)
                                    .then((response) => {
                                    this.$refs.deleteAdmin.parentNode.parentNode.remove();
                                    location.reload();
                                    });
                            } else {
                                swal("Your imaginary file is safe!");
                            }
                        });
                }
            },
        })
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_dash', ['title' => 'Dashboard - admin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\A C E R\Desktop\web_api_wisata\resources\views/backend/admin.blade.php ENDPATH**/ ?>