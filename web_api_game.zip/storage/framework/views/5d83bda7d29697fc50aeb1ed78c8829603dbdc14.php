<div class="position-relative form-group">
    <label for="bg" class="">BG</label>
    <?php if(empty(!$travel->bg)): ?>
    <img src="<?php echo e($travel->takeImg); ?>" alt="Error" width="100" for="img">
    <?php endif; ?>
    <input name="bg" id="bg"  type="file" accept="image/*" class="form-control" autofocus>
    <?php $__errorArgs = ['bg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small> 
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="position-relative form-group">
    <label for="nama" class="">Nama</label>
    <input name="name" id="nama" placeholder="nama wisata" autocomplete="off" type="text" class="form-control" value="<?php echo e(old('name') ?? $travel->name); ?>">
    <?php if($errors->has('name')): ?>
        <small class="text-danger"><?php echo e($errors->first('name')); ?></small>
    <?php endif; ?>
</div>
<div class="position-relative form-group">
    <label for="description" class="">Deskripsi</label>
    <textarea name="description" id="description" placeholder="deskripsi wisata" class="form-control" ><?php echo e(old('description') ?? $travel->description); ?></textarea>
    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small> 
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="position-relative form-group">
    <label for="location" class="">Lokasi</label>
    <input name="location" id="location" placeholder="lokasi wisata" autocomplete="off" type="text" class="form-control" value="<?php echo e(old('location') ?? $travel->location); ?>">
    <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div><?php /**PATH C:\Users\A C E R\Desktop\web_api_wisata\resources\views/components/backend/travel_form.blade.php ENDPATH**/ ?>