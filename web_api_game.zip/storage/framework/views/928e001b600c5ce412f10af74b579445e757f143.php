<!doctype html>
<html lang="en">
<head>
    <title><?php echo e($title ?? 'Dashboard'); ?></title>
    <?php echo $__env->make('includes.meta_dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.css_dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('css_select_two'); ?>
</head>
<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header">
        
        
        <?php echo $__env->make('layouts.master_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="app-main">
            
            <?php echo $__env->make('layouts.master_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="app-main__outer">
            
            <?php echo $__env->yieldContent('content'); ?>
            
            <?php echo $__env->make('layouts.master_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
    <?php echo $__env->make('includes.script_dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('script_select_two'); ?>
    <?php echo $__env->yieldPushContent('script_vue_js_axios_sweet'); ?>
    <?php echo $__env->yieldPushContent('script_ckeditor'); ?>
</body>

</html>
<?php /**PATH C:\Users\A C E R\Desktop\web_api_game\resources\views/layouts/master_dash.blade.php ENDPATH**/ ?>