<div class="position-relative form-group">
    <label for="img" class="">Gambar</label>
    <?php if(empty(!$game->img)): ?>
    <img src="<?php echo e($game->takeImg); ?>" alt="Error" width="100" for="img">
    <?php endif; ?>
    <input name="img" id="img"  type="file" accept="image/*" class="form-control" autofocus>
    <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small> 
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="position-relative form-group">
    <label for="nama" class="">Nama</label>
    <input name="name" id="nama" placeholder="Nama permainan" autocomplete="off" type="text" class="form-control" value="<?php echo e(old('name') ?? $game->name); ?>">
    <?php if($errors->has('name')): ?>
    <small class="text-danger"><?php echo e($errors->first('name')); ?></small>
    <?php endif; ?>
</div>
<div class="position-relative form-group">
    <label for="duration" class="">Durasi (Menit)</label>
    <input name="duration" id="duration" placeholder="Lama permainan (menit)" autocomplete="off" type="number" class="form-control" value="<?php echo e(old('duration') ?? $game->duration); ?>">
    <?php $__errorArgs = ['duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="position-relative form-group">
    <label for="description" class="">Deskripsi</label>
    <textarea name="description" id="description" placeholder="Deskripsi permainan" class="form-control" ><?php echo e(old('description') ?? $game->description); ?></textarea>
    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small> 
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div><?php /**PATH C:\Users\A C E R\Desktop\web_api_game\resources\views/components/backend/game_form.blade.php ENDPATH**/ ?>